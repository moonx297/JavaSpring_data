package com.spring.ex01;

public interface PersonService {

	void sayHello();

}
