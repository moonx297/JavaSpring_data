package com.spring.ex04;

public class Third {
	
	public Third() {
		System.out.println("Third 생성자 호출");
	}
}
