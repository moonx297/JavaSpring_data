package com.spring.ex04;

public class Second {

	public Second() {
		System.out.println("Second 생성자 호출");
	}
}
